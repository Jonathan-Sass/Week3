let i = 0;
//Print odds 1 - 20
// for (i = 1; i <= 20; i++) {
//     if(i % 2 == 1) {
//         console.log(i);
//     }
// }

//Decreasing Multiples of 3 from 100
// for (i = 100; i >= 0; i--) {
//     if (i % 3 == 0) {
//         console.log(i);
//     }
// }
//Print the sequence 4, 2.5, 1, =0.5, -2 with a loop
// for (i = 4; i >= -2; i -= 1.5) {
//     console.log(i);
// }

//Sigma - adds values of 1 - 100 into a sum variable, at the end console.log the result
// let sum = 0;
// for (i = 1; i <= 100; i++) {
//     sum += i;
// }
// console.log(sum);

// Factorial - multiply all values from 1 - 12 onto var product, then clog the result
let product = 1;
for (i = 1; i <= 12; i++) {
    product *= i;
}
console.log(product);